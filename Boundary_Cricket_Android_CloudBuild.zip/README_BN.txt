BOUNDARY CRICKET - ANDROID PROJECT
===================================
This project includes a GitHub Actions workflow to build a debug APK in the cloud.

PHONE-ONLY BUILD STEPS:
1. Download and extract this ZIP using your Android file manager or a ZIP app.
2. Create/sign in to a GitHub account at https://github.com.
3. In GitHub, create a new repository named boundary-cricket (Public or Private).
4. Open the new repository, choose Add file > Upload files.
5. Upload the CONTENTS of this project folder (including the hidden .github folder and its workflow file), then Commit changes.
   IMPORTANT: GitHub's browser uploader may hide dot-folders. If .github/workflows/android.yml cannot be uploaded from your phone, create it on GitHub using Add file > Create new file and name it exactly:
   .github/workflows/android.yml
   Then paste the workflow content from the included android.yml file.
6. Open the repository's Actions tab. Select "Build Boundary Cricket APK" and tap Run workflow if it has not started automatically.
7. Wait for the workflow to finish successfully. Open the completed run and download the artifact named Boundary-Cricket-debug-APK.
8. Extract the downloaded artifact ZIP and tap app-debug.apk to install. Android may ask permission to install unknown apps; only allow this for the file you built yourself.

PROJECT DETAILS:
- Package: com.boundarycricket.app
- Version: 1.0
- Minimum Android: 6.0 (API 23)
- Build: Debug APK (testing only)

NOTES:
- The cloud build runs on GitHub Actions. You need a GitHub account and internet.
- Debug APK is for testing, not a Play Store release. A signed release build and device testing are needed before publishing.
- This is an early 2D playable prototype, not a full 3D cricket game.
- Never upload signing keys, passwords, or private secrets to a public repository.
